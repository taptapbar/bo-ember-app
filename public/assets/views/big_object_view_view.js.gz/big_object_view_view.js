App.BigObjectViewView = Ember.View.extend({
  templateName: 'big_object_view',
  
  didInsertElement: function() {
    //console.log("render BigObjectViewView");
  }
});
