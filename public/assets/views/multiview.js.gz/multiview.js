App.ColumnChartView = App.ChartView.extend({
  type: 'column'
});
